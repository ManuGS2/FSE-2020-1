#include <stdio.h>

int main(int argc, char **argv) {

	int i;
	
	for(i=1; i<16; i++)
		printf("#%i: FSE2020-1 Emmanuel Guzman, Aaron Mejia, Ricardo Saenz\n", i);

	return 0;
}
